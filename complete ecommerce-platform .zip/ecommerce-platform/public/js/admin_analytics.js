// admin_analytics.js (FINAL)

document.addEventListener("DOMContentLoaded", loadAnalytics);

async function loadAnalytics() {
    const res = await fetch("/api/admin/stats");
    const stats = await res.json();

    document.getElementById("rev").innerText = "₹" + stats.totalRevenue;
    document.getElementById("avg").innerText = "₹" + stats.avgOrder;
    document.getElementById("cnt").innerText = stats.orderCount;

    loadCharts(stats);
}

function loadCharts(stats) {

    // ------------- REVENUE BAR CHART ----------------
    new Chart(document.getElementById("revenueChart"), {
        type: "bar",
        data: {
            labels: ["Revenue"],
            datasets: [{
                label: "Total Revenue (₹)",
                data: [stats.totalRevenue],
                borderWidth: 1
            }]
        }
    });

    // ------------- ORDERS BAR CHART ----------------
    new Chart(document.getElementById("ordersChart"), {
        type: "bar",
        data: {
            labels: ["Orders"],
            datasets: [{
                label: "Total Orders",
                data: [stats.orderCount],
                borderWidth: 1
            }]
        }
    });
}
