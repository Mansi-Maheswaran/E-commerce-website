// server.js
// Merged final server (keeps current functionality; cart & orders restored with safe _id deletion)

const http = require("http");
const fs = require("fs");
const path = require("path");
const { MongoClient, ObjectId } = require("mongodb");
const bcrypt = require("bcrypt");

// If you have a models/order file, keep it; fallback to minimal if missing
let OrderModelClass;
try {
  OrderModelClass = require("./models/order");
} catch (e) {
  // Minimal stub if models/order is not present — avoids server crash.
  OrderModelClass = class {
    constructor(db) { this.db = db; }
    async createOrder(o) {
      const result = await this.db.collection("orders").insertOne(o);
      return { insertedId: result.insertedId, order: o };
    }
    async getOrdersByUser(email, filter) {
      return this.db.collection("orders").find({ userEmail: email }).toArray();
    }
    async getOrderByOrderId(orderId) {
      return this.db.collection("orders").findOne({ orderId });
    }
    async cancelOrder(orderId, refundAmount, convenienceCharge) {
      await this.db.collection("orders").updateOne({ orderId }, { $set: { status: "Cancelled", refundAmount, convenienceCharge } });
      return this.db.collection("orders").findOne({ orderId });
    }
  };
}

const uri = "mongodb://127.0.0.1:27017";
const client = new MongoClient(uri);
const dbName = "ecommercePlatformDB";
let db;
let orderModel;

async function connectDB() {
  try {
    await client.connect();
    db = client.db(dbName);
    orderModel = new OrderModelClass(db);
    console.log("✅ Connected to MongoDB locally!");
    console.log(`✅ Connected to ${dbName} database!`);

    // ensure admin exists
    const admin = await db.collection("admins").findOne({ email: "admin@gmail.com" });
    if (!admin) {
      const hashed = await bcrypt.hash("admin123", 10);
      await db.collection("admins").insertOne({
        name: "Admin",
        email: "admin@gmail.com",
        password: hashed
      });
      console.log("✅ Admin created with email: admin@gmail.com / password: admin123");
    } else {
      console.log("ℹ️ Admin already exists:", admin.email);
    }
  } catch (err) {
    console.error("❌ MongoDB connection error:", err);
  }
}
connectDB();

// serve file helper
function serveFile(filePath, contentType, res) {
  fs.readFile(filePath, (err, content) => {
    if (err) {
      res.writeHead(404, { "Content-Type": "text/plain" });
      return res.end("404 Not Found");
    }
    res.writeHead(200, { "Content-Type": contentType });
    res.end(content, "utf-8");
  });
}

const mimeTypes = {
  ".html": "text/html",
  ".css": "text/css",
  ".js": "application/javascript",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".gif": "image/gif",
  ".svg": "image/svg+xml",
  ".json": "application/json",
  ".ico": "image/x-icon"
};

const server = http.createServer(async (req, res) => {
  const rawUrl = req.url || "/";
  const urlPath = rawUrl.split("?")[0];
  console.log("➡️ Request:", rawUrl);

  // Static pages (kept same)
  if (urlPath === "/" || urlPath === "/html/login.html") {
    return serveFile(path.join(__dirname, "public/html/login.html"), "text/html", res);
  }
  if (urlPath === "/html/register.html") {
    return serveFile(path.join(__dirname, "public/html/register.html"), "text/html", res);
  }
  if (urlPath === "/html/home.html") {
    return serveFile(path.join(__dirname, "public/html/home.html"), "text/html", res);
  }
  if (urlPath === "/html/admin_dashboard.html") {
    return serveFile(path.join(__dirname, "public/html/admin_dashboard.html"), "text/html", res);
  }
  if (urlPath === "/html/admin_login.html") {
    return serveFile(path.join(__dirname, "public/html/admin_login.html"), "text/html", res);
  }
  if (urlPath === "/html/order_details.html") {
    return serveFile(path.join(__dirname, "public/html/order_details.html"), "text/html", res);
  }
  if (urlPath === "/html/cart.html") {
    return serveFile(path.join(__dirname, "public/html/cart.html"), "text/html", res);
  }
  if (urlPath === "/html/orders.html") {
    return serveFile(path.join(__dirname, "public/html/orders.html"), "text/html", res);
  }
  if (urlPath === "/html/payment.html") {
    return serveFile(path.join(__dirname, "public/html/payment.html"), "text/html", res);
  }
  if (urlPath.startsWith("/public/")) {
    const cleanPath = urlPath.split("?")[0];
    const filePath = path.join(__dirname, cleanPath);
    const ext = path.extname(filePath).toLowerCase();
    const contentType = mimeTypes[ext] || "application/octet-stream";
    return serveFile(filePath, contentType, res);
  }
  if (urlPath === "/user/invoice.html" || urlPath === "/public/user/invoice.html") {
    return serveFile(path.join(__dirname, "public/user/invoice.html"), "text/html", res);
  }

  // helper to collect body
  function readBody(cb) {
    let body = "";
    req.on("data", chunk => (body += chunk));
    req.on("end", () => cb(body));
    req.on("error", () => cb(""));
  }

  // REGISTER
  if (rawUrl === "/api/register" && req.method === "POST") {
    return readBody(async (body) => {
      try {
        const { name, email, password } = JSON.parse(body);
        if (!email || !password) {
          res.writeHead(400, { "Content-Type": "application/json" });
          return res.end(JSON.stringify({ message: "Email and password required" }));
        }
        const existingUser = await db.collection("users").findOne({ email });
        if (existingUser) {
          res.writeHead(400, { "Content-Type": "application/json" });
          return res.end(JSON.stringify({ message: "User already exists" }));
        }
        const hashedPassword = await bcrypt.hash(password, 10);
        await db.collection("users").insertOne({ name, email, password: hashedPassword, createdAt: new Date() });
        res.writeHead(200, { "Content-Type": "application/json" });
        return res.end(JSON.stringify({ message: "Registration successful" }));
      } catch (err) {
        console.error("register error", err);
        res.writeHead(500, { "Content-Type": "application/json" });
        return res.end(JSON.stringify({ message: "Error registering user" }));
      }
    });
  }

  // LOGIN
  if (rawUrl === "/api/login" && req.method === "POST") {
    return readBody(async (body) => {
      try {
        const { email, password } = JSON.parse(body || "{}");
        if (!email || !password) {
          res.writeHead(400, { "Content-Type": "application/json" });
          return res.end(JSON.stringify({ message: "Email and password required" }));
        }

        const admin = await db.collection("admins").findOne({ email });
        if (admin && (await bcrypt.compare(password, admin.password))) {
          res.writeHead(200, { "Content-Type": "application/json" });
          return res.end(JSON.stringify({ message: "Admin login successful", role: "admin" }));
        }

        const user = await db.collection("users").findOne({ email });
        if (user && (await bcrypt.compare(password, user.password))) {
          res.writeHead(200, { "Content-Type": "application/json" });
          return res.end(JSON.stringify({ message: "User login successful", role: "user" }));
        }

        res.writeHead(401, { "Content-Type": "application/json" });
        return res.end(JSON.stringify({ message: "Invalid credentials" }));
      } catch (err) {
        console.error("login error", err);
        res.writeHead(500, { "Content-Type": "application/json" });
        return res.end(JSON.stringify({ message: "Login failed" }));
      }
    });
  }

  // ADD PRODUCT
  if (rawUrl === "/api/products" && req.method === "POST") {
    return readBody(async (body) => {
      try {
        const data = JSON.parse(body || "{}");
        if (data.price !== undefined) data.price = Number(data.price) || 0;
        if (data.stock !== undefined) data.stock = Number(data.stock) || 0;
        data.addedAt = new Date();
        await db.collection("products").insertOne(data);
        res.writeHead(200, { "Content-Type": "application/json" });
        return res.end(JSON.stringify({ message: "Product added successfully" }));
      } catch (err) {
        console.error("add product error", err);
        res.writeHead(500, { "Content-Type": "application/json" });
        return res.end(JSON.stringify({ message: "Error adding product" }));
      }
    });
  }

  // GET PRODUCTS (supports filters)
  if (urlPath.startsWith("/api/products") && req.method === "GET") {
    try {
      const parts = rawUrl.split("?");
      const queryParams = new URLSearchParams(parts[1] || "");
      const filter = {};

      if (queryParams.get("name")) {
        filter.name = { $regex: new RegExp(queryParams.get("name"), "i") };
      }
      if (queryParams.get("category")) {
        filter.category = queryParams.get("category");
      }
      if (queryParams.get("gender")) {
        filter.gender = queryParams.get("gender");
      }
      const minP = queryParams.get("minPrice");
      const maxP = queryParams.get("maxPrice");
      if (minP || maxP) {
        filter.price = {};
        if (minP) filter.price.$gte = Number(minP);
        if (maxP) filter.price.$lte = Number(maxP);
      }

      const products = await db.collection("products").find(filter).toArray();
      res.writeHead(200, { "Content-Type": "application/json" });
      return res.end(JSON.stringify(products));
    } catch (err) {
      console.error("get products error", err);
      res.writeHead(500, { "Content-Type": "application/json" });
      return res.end(JSON.stringify({ message: "Error fetching products" }));
    }
  }

  // DELETE PRODUCT
  if (rawUrl.startsWith("/api/products/") && req.method === "DELETE") {
    const id = urlPath.split("/").pop();
    try {
      await db.collection("products").deleteOne({ _id: new ObjectId(id) });
      res.writeHead(200, { "Content-Type": "application/json" });
      return res.end(JSON.stringify({ message: "Product deleted" }));
    } catch (err) {
      console.error("delete product error", err);
      res.writeHead(500, { "Content-Type": "application/json" });
      return res.end(JSON.stringify({ message: "Deletion error" }));
    }
  }

  // UPDATE PRODUCT
  if (rawUrl.startsWith("/api/products/") && req.method === "PUT") {
    const id = urlPath.split("/").pop();
    return readBody(async (body) => {
      try {
        const data = JSON.parse(body || "{}");
        if (data.price !== undefined) data.price = Number(data.price) || 0;
        if (data.stock !== undefined) data.stock = Number(data.stock) || 0;
        await db.collection("products").updateOne({ _id: new ObjectId(id) }, { $set: data });
        res.writeHead(200, { "Content-Type": "application/json" });
        return res.end(JSON.stringify({ message: "Product updated" }));
      } catch (err) {
        console.error("update product error", err);
        res.writeHead(500, { "Content-Type": "application/json" });
        return res.end(JSON.stringify({ message: "Update error" }));
      }
    });
  }

  // PAYMENT (create order + payment record)
  if (rawUrl === "/api/payment" && req.method === "POST") {
    return readBody(async (body) => {
      try {
        const data = JSON.parse(body || "{}");
        const { userEmail, items, paymentMethod, cardNumber, name, address } = data;
        if (!items || !Array.isArray(items) || items.length === 0) {
          res.writeHead(400, { "Content-Type": "application/json" });
          return res.end(JSON.stringify({ message: "No items provided" }));
        }

        // ensure numeric
        items.forEach(it => {
          if (it.price !== undefined) it.price = Number(it.price) || 0;
          if (it.quantity !== undefined) it.quantity = Number(it.quantity) || 1;
        });

        await db.collection("payments").insertOne({
          userEmail, items, paymentMethod, cardNumber: cardNumber ? String(cardNumber).slice(-4) : null,
          name, address, paymentDate: new Date(), status: "Success"
        });

        const totalAmount = items.reduce((s, it) => s + (Number(it.price || 0) * Number(it.quantity || 1)), 0);
        const orderId = new ObjectId().toString();
        const orderData = {
          orderId, 
          userEmail: String(userEmail || "").trim().toLowerCase(),

          items: items.map(it => ({
            productId: it.productId, productName: it.productName, price: Number(it.price || 0), quantity: Number(it.quantity || 1),
            image: it.image || null, size: it.size || null
          })),
          totalAmount, paymentMethod, paymentDate: new Date(), createdAt: new Date(), status: "Processing"
        };

        await db.collection("orders").insertOne(orderData);

        // Keep NEW behavior (Option B): delete ONLY purchased cart items by _id (if provided)
        const purchasedIds = items
          .map(it => it._id ? (typeof it._id === "string" ? new ObjectId(it._id) : it._id) : null)
          .filter(Boolean);

        if (purchasedIds.length > 0) {
          await db.collection("cart").deleteMany({
            userEmail,
            _id: { $in: purchasedIds }
          });
        } else {
          // Fallback: if no _id present, try deleting by productId (best-effort)
          const purchasedProductIds = items.map(it => it.productId).filter(Boolean);
          if (purchasedProductIds.length > 0) {
            await db.collection("cart").deleteMany({
              userEmail,
              productId: { $in: purchasedProductIds }
            });
          }
        }

        res.writeHead(200, { "Content-Type": "application/json" });
        return res.end(JSON.stringify({ message: "Payment successful", orderId }));
      } catch (err) {
        console.error("payment error:", err);
        res.writeHead(500, { "Content-Type": "application/json" });
        return res.end(JSON.stringify({ message: "Payment failed" }));
      }
    });
  }

  // ADD TO CART
  if (rawUrl === "/api/cart" && req.method === "POST") {
    return readBody(async (body) => {
      try {
        const data = JSON.parse(body || "{}");
        data.price = Number(data.price || 0);
        data.quantity = Number(data.quantity || 1);
        data.addedAt = new Date();

        const result = await db.collection("cart").insertOne(data);
        // respond with inserted id so frontend can keep reference (_id) for safe deletion later
        res.writeHead(200, { "Content-Type": "application/json" });
        return res.end(JSON.stringify({ message: "Item added to cart successfully", insertedId: result.insertedId }));
      } catch (err) {
        console.error("add to cart error", err);
        res.writeHead(500, { "Content-Type": "application/json" });
        return res.end(JSON.stringify({ message: "Error adding to cart" }));
      }
    });
  }

  // GET CART
  if (urlPath.startsWith("/api/cart/") && req.method === "GET") {
    const userEmail = decodeURIComponent(urlPath.split("/").pop());
    try {
      const cartItems = await db.collection("cart").find({ userEmail }).toArray();
      res.writeHead(200, { "Content-Type": "application/json" });
      return res.end(JSON.stringify(cartItems));
    } catch (err) {
      console.error("get cart error", err);
      res.writeHead(500, { "Content-Type": "application/json" });
      return res.end(JSON.stringify({ message: "Error fetching cart" }));
    }
  }

  // UPDATE CART QUANTITY
  if (urlPath.startsWith("/api/cart/updateQuantity/") && req.method === "PUT") {
    const id = urlPath.split("/").pop();
    return readBody(async (body) => {
      try {
        const { quantity } = JSON.parse(body || "{}");
        await db.collection("cart").updateOne({ _id: new ObjectId(id) }, { $set: { quantity: Number(quantity) } });
        res.writeHead(200, { "Content-Type": "application/json" });
        return res.end(JSON.stringify({ message: "Quantity updated successfully" }));
      } catch (err) {
        console.error("update cart quantity error", err);
        res.writeHead(500, { "Content-Type": "application/json" });
        return res.end(JSON.stringify({ message: "Error updating quantity" }));
      }
    });
  }

  // GET ORDERS (BY USER)
  if (urlPath.startsWith("/api/orders/") && req.method === "GET" && rawUrl.indexOf("/api/orders/id/") === -1) {
    try {
      const base = rawUrl.split("?")[0];
      const email = String(decodeURIComponent(base.split("/").pop()) || "")
              .trim()
              .toLowerCase();

      const orders = await db.collection("orders").find({ userEmail: email }).sort({ paymentDate: -1 })
.toArray();
      res.writeHead(200, { "Content-Type": "application/json" });
      return res.end(JSON.stringify(orders));
    } catch (err) {
      console.error("get user orders error", err);
      res.writeHead(500, { "Content-Type": "application/json" });
      return res.end(JSON.stringify({ message: "Error fetching orders" }));
    }
  }

  // GET single order by id
  if (rawUrl.startsWith("/api/orders/id/") && req.method === "GET") {
    const orderId = urlPath.split("/").pop();
    try {
      const order = await db.collection("orders").findOne({ orderId });
      if (!order) {
        res.writeHead(404, { "Content-Type": "application/json" });
        return res.end(JSON.stringify({ message: "Order not found" }));
      }
      res.writeHead(200, { "Content-Type": "application/json" });
      return res.end(JSON.stringify(order));
    } catch (err) {
      console.error("get order by id error", err);
      res.writeHead(500, { "Content-Type": "application/json" });
      return res.end(JSON.stringify({ message: "Error fetching order" }));
    }
  }

  // UPDATE ORDER STATUS (ADMIN)
  if (rawUrl.startsWith("/api/orders/updateStatus/") && req.method === "PUT") {
    const orderId = urlPath.split("/").pop();
    return readBody(async (body) => {
      try {
        const { status } = JSON.parse(body || "{}");
        if (!status) {
          res.writeHead(400, { "Content-Type": "application/json" });
          return res.end(JSON.stringify({ message: "Status required" }));
        }
        await db.collection("orders").updateOne({ orderId }, { $set: { status } });
        if (status.toLowerCase() === "delivered") {
          await db.collection("orders").updateOne({ orderId }, { $set: { deliveredAt: new Date() } });
        }
        res.writeHead(200, { "Content-Type": "application/json" });
        return res.end(JSON.stringify({ message: "Order status updated" }));
      } catch (err) {
        console.error("update order status error", err);
        res.writeHead(500, { "Content-Type": "application/json" });
        return res.end(JSON.stringify({ message: "Error updating status" }));
      }
    });
  }

  // INVOICE DATA
  if (rawUrl.startsWith("/invoice/") && req.method === "GET") {
    const orderId = urlPath.split("/").pop();
    try {
      const order = await db.collection("orders").findOne({ orderId });
      if (!order) {
        res.writeHead(404, { "Content-Type": "application/json" });
        return res.end(JSON.stringify({ success: false, message: "Order not found" }));
      }
      res.writeHead(200, { "Content-Type": "application/json" });
      return res.end(JSON.stringify({ success: true, order }));
    } catch (err) {
      console.error("invoice error", err);
      res.writeHead(500, { "Content-Type": "application/json" });
      return res.end(JSON.stringify({ success: false, message: "Server error" }));
    }
  }

  // CANCEL ORDER
  if (rawUrl.startsWith("/api/orders/cancel/") && req.method === "PUT") {
    const orderId = urlPath.split("/").pop();
    try {
      const order = await db.collection("orders").findOne({ orderId });
      if (!order) {
        res.writeHead(404, { "Content-Type": "application/json" });
        return res.end(JSON.stringify({ message: "Order not found" }));
      }
      if (order.status && order.status === "Cancelled") {
        res.writeHead(400, { "Content-Type": "application/json" });
        return res.end(JSON.stringify({ message: "Order already cancelled" }));
      }
      const convenienceCharge = Math.round(Number(order.totalAmount || 0) * 0.03);
      const refundAmount = Number(order.totalAmount || 0) - convenienceCharge;

      await db.collection("orders").updateOne({ orderId }, { $set: { status: "Cancelled", refundAmount, convenienceCharge } });

      await db.collection("refunds").insertOne({ orderId, userEmail: order.userEmail, refundAmount, convenienceCharge, refundDate: new Date() });

      res.writeHead(200, { "Content-Type": "application/json" });
      return res.end(JSON.stringify({ message: "Order cancelled", refundAmount, convenienceCharge }));
    } catch (err) {
      console.error("cancel error", err);
      res.writeHead(500, { "Content-Type": "application/json" });
      return res.end(JSON.stringify({ message: "Cancel failed" }));
    }
  }

  // REMOVE CART ITEM
  if (rawUrl.startsWith("/api/cart/remove/") && req.method === "DELETE") {
    const id = urlPath.split("/").pop();
    try {
      await db.collection("cart").deleteOne({ _id: new ObjectId(id) });
      res.writeHead(200, { "Content-Type": "application/json" });
      return res.end(JSON.stringify({ message: "Item removed" }));
    } catch (err) {
      console.error("remove cart item error", err);
      res.writeHead(500, { "Content-Type": "application/json" });
      return res.end(JSON.stringify({ message: "Error removing item" }));
    }
  }

  // ADMIN: GET USERS
  if (rawUrl === "/api/admin/users" && req.method === "GET") {
    try {
      const users = await db.collection("users").find({}, { projection: { password: 0 } }).toArray();
      res.writeHead(200, { "Content-Type": "application/json" });
      return res.end(JSON.stringify(users));
    } catch (err) {
      console.error("admin users error", err);
      res.writeHead(500, { "Content-Type": "application/json" });
      return res.end(JSON.stringify({ message: "Error fetching users" }));
    }
  }
  if (urlPath === "/api/admin/products" && req.method === "GET") {
  try {
    const params = new URLSearchParams(rawUrl.split("?")[1] || "");
    const q = {};

    const name = params.get("name");
    const category = params.get("category");
    const min = params.get("min");
    const max = params.get("max");

    if (name) q.productName = { $regex: name, $options: "i" };
    if (category && category !== "all") {
      
  q.category = { $regex: `^${category.trim()}$`, $options: "i" };


    }

    if (min) q.price = Object.assign(q.price || {}, { $gte: Number(min) });
    if (max) q.price = Object.assign(q.price || {}, { $lte: Number(max) });

    const products = await db.collection("products").find(q).toArray();
    res.writeHead(200, { "Content-Type": "application/json" });
    return res.end(JSON.stringify(products));
  } catch (err) {
    console.error("admin products filter error", err);
    res.writeHead(500, { "Content-Type": "application/json" });
    return res.end(JSON.stringify({ message: "Error fetching filtered products" }));
  }
}


  // ADMIN: GET ORDERS
  if (urlPath.startsWith("/api/admin/orders") && req.method === "GET") {
    try {
      const parts = rawUrl.split("?");
      const params = new URLSearchParams(parts[1] || "");
      const filter = {};
      if (params.get("userEmail")) filter.userEmail = params.get("userEmail");
      if (params.get("status")) filter.status = params.get("status");
      const orders = await db.collection("orders").find(filter).toArray();
      res.writeHead(200, { "Content-Type": "application/json" });
      return res.end(JSON.stringify(orders));
    } catch (err) {
      console.error("admin orders error", err);
      res.writeHead(500, { "Content-Type": "application/json" });
      return res.end(JSON.stringify({ message: "Error fetching orders" }));
    }
  }

  // ADMIN: STATS / ANALYTICS (fixed — coercion added)
  if (rawUrl === "/api/admin/stats" && req.method === "GET") {
    try {
      const productsCount = await db.collection("products").countDocuments();
      const usersCount = await db.collection("users").countDocuments();
      const ordersCount = await db.collection("orders").countDocuments();

      // order status aggregation
      const statusAgg = await db.collection("orders").aggregate([
        { $group: { _id: "$status", count: { $sum: 1 } } }
      ]).toArray();
      const orderStatus = {};
      statusAgg.forEach(s => { orderStatus[s._id || "Unknown"] = s.count; });

      // sales last 30 days
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 29);

      const salesAgg = await db.collection("orders").aggregate([
        { $match: { paymentDate: { $gte: thirtyDaysAgo } } },
        { $unwind: "$items" },
        {
          $project: {
            day: { $dateToString: { format: "%Y-%m-%d", date: "$paymentDate" } },
            priceNum: { $toDouble: { $ifNull: ["$items.price", 0] } },
            qtyNum: { $toDouble: { $ifNull: ["$items.quantity", 1] } }
          }
        },
        {
          $group: {
            _id: "$day",
            total: { $sum: { $multiply: ["$priceNum", "$qtyNum"] } }
          }
        },
        { $sort: { _id: 1 } }
      ]).toArray();

      const last30Days = [];
      for (let i = 29; i >= 0; i--) {
        const d = new Date();
        d.setDate(d.getDate() - i);
        const key = d.toISOString().slice(0, 10);
        const found = salesAgg.find(s => s._id === key);
        last30Days.push({ day: key, total: found ? found.total : 0 });
      }

      const totalRevenueLast30 = last30Days.reduce((s, x) => s + Number(x.total || 0), 0);

      const topAgg = await db.collection("orders").aggregate([
        { $match: { paymentDate: { $gte: thirtyDaysAgo } } },
        { $unwind: "$items" },
        {
          $project: {
            productId: "$items.productId",
            productName: "$items.productName",
            qtyNum: { $toDouble: { $ifNull: ["$items.quantity", 1] } }
          }
        },
        {
          $group: {
            _id: "$productId",
            name: { $first: "$productName" },
            qty: { $sum: "$qtyNum" }
          }
        },
        { $sort: { qty: -1 } },
        { $limit: 6 }
      ]).toArray();

      const topSelling = topAgg.map(t => ({
        productId: t._id, productName: t.name, qty: Math.round(Number(t.qty) || 0)
      }));

      const ordersLast30 = await db.collection("orders").find({ paymentDate: { $gte: thirtyDaysAgo } }).toArray();
      const ordersCountLast30 = ordersLast30.length;
      const avgOrderValue = ordersCountLast30
        ? (ordersLast30.reduce((s, o) => s + Number(o.totalAmount || 0), 0) / ordersCountLast30)
        : 0;

      res.writeHead(200, { "Content-Type": "application/json" });
      return res.end(JSON.stringify({
        productsCount,
        usersCount,
        ordersCount,
        orderStatus,
        last30Days,
        totalRevenueLast30,
        topSelling,
        ordersCountLast30,
        avgOrderValue
      }));
    } catch (err) {
      console.error("admin stats error", err);
      res.writeHead(500, { "Content-Type": "application/json" });
      return res.end(JSON.stringify({ message: "Error computing stats" }));
    }
  }

  // fallback 404
  res.writeHead(404, { "Content-Type": "text/plain" });
  res.end("404 Not Found");
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
});
