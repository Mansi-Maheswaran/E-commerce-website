// db.js
const { MongoClient } = require("mongodb");

async function connectDB() {
  const url = "mongodb://127.0.0.1:27017"; // Local MongoDB
  const client = new MongoClient(url);

  try {
    await client.connect();
    console.log("✅ Connected to MongoDB locally!");
    const db = client.db("ecommercePlatformDB"); // New DB name
    return db;
  } catch (err) {
    console.error("❌ Database connection failed:", err);
    return null;
  }
}

module.exports = connectDB;
