// models/order.js
const { ObjectId } = require("mongodb");

class OrderModel {
  constructor(db) {
    this.collection = db.collection("orders");
  }

  // create a grouped order
  async createOrder(orderData) {
    // add a readable orderId (string)
    const insert = Object.assign({}, orderData, {
      createdAt: new Date(),
      orderId: new ObjectId().toString()
    });
    const result = await this.collection.insertOne(insert);
    return { insertedId: result.insertedId, order: insert };
  }

  // get orders for a user; optional filter: '30days' or 'all'
  async getOrdersByUser(email, filter = "all") {
    const q = { userEmail: email };
    if (filter === "30days") {
      const since = new Date();
      since.setDate(since.getDate() - 30);
      q.paymentDate = { $gte: since };
    }
    const cursor = await this.collection.find(q).sort({ paymentDate: -1 });
    return cursor.toArray();
  }

  // get single order by orderId (string)
  async getOrderByOrderId(orderId) {
    return await this.collection.findOne({ orderId });
  }

  // cancel order: set status and refund info
  async cancelOrder(orderId, refundAmount, convenienceCharge) {
    const update = {
      $set: {
        status: "Cancelled",
        cancelledAt: new Date(),
        refundAmount,
        convenienceCharge
      }
    };
    await this.collection.updateOne({ orderId }, update);
    return await this.getOrderByOrderId(orderId);
  }
}

module.exports = OrderModel;
