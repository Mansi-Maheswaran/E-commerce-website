// models/userModel.js
const bcrypt = require("bcrypt");

async function registerUser(db, name, email, password) {
  try {
    const users = db.collection("users");

    // Check if the user already exists
    const existingUser = await users.findOne({ email: email });
    if (existingUser) {
      console.log("⚠️ User already exists:", email);
      return false;
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Insert new user
    const result = await users.insertOne({
      name: name,
      email: email,
      password: hashedPassword
    });

    console.log("✅ User registered successfully:", email);
    return result.acknowledged;
  } catch (error) {
    console.error("❌ Error registering user:", error);
    return false;
  }
}

async function findUser(db, email) {
  const users = db.collection("users");
  const user = await users.findOne({ email: email });
  return user;
}

module.exports = { registerUser, findUser };