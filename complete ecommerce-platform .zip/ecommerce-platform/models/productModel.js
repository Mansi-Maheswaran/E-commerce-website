// models/productModel.js
async function addProduct(db, name, price, description, stock) {
  await db.collection("products").insertOne({ name, price, description, stock });
}

async function getAllProducts(db) {
  return await db.collection("products").find().toArray();
}

async function deleteProduct(db, name) {
  await db.collection("products").deleteOne({ name });
}

module.exports = { addProduct, getAllProducts, deleteProduct };
