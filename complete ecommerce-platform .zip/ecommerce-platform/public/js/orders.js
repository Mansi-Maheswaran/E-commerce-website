// public/js/orders.js
document.addEventListener("DOMContentLoaded", initOrders);

async function initOrders() {
  const userEmail = localStorage.getItem("userEmail");
  if (!userEmail) {
    alert("Please login first");
    window.location.href = "login.html";
    return;
  }

  // build UI controls (filter)
  const container = document.getElementById("ordersContainer");
  const controlsEl = document.createElement("div");
  controlsEl.style.maxWidth = "900px";
  controlsEl.style.margin = "12px auto";
  controlsEl.innerHTML = `
    <div style="display:flex;gap:12px;align-items:center;justify-content:flex-end;margin-bottom:8px">
      <label style="font-weight:600">Show:</label>
      <select id="ordersFilter">
        <option value="30days">Last 30 days</option>
        <option value="all" selected>All orders</option>
      </select>
    </div>
  `;
  container.parentElement.insertBefore(controlsEl, container);

  document.getElementById("ordersFilter").addEventListener("change", () => loadOrders(userEmail));

  await loadOrders(userEmail);
}

async function loadOrders(userEmail) {
  const filter = document.getElementById("ordersFilter").value || "all";
  const res = await fetch(`/api/orders/${encodeURIComponent(userEmail)}?filter=${encodeURIComponent(filter)}`);
  const orders = await res.json();

  const container = document.getElementById("ordersContainer");
  container.innerHTML = "";

  if (!orders || orders.length === 0) {
    container.innerHTML = `<p class="empty">No orders found.</p>`;
    return;
  }

  orders.forEach(order => {
    const card = document.createElement("div");
    card.className = "order-card";

    const itemsList = order.items || order.orderedItems || [];
    const itemsHtml = itemsList.map(it => `

      <div style="display:flex;gap:8px;align-items:center;margin-bottom:6px">
        <img src="${escapeHtml(it.image || 'https://via.placeholder.com/80')}" width="60" height="60" style="object-fit:cover;border-radius:6px"/>
        <div>
          <div style="font-weight:700">${escapeHtml(it.productName)}</div>
          <div>Qty: ${escapeHtml(it.quantity)} • ₹${escapeHtml(it.price)}</div>
        </div>
      </div>
    `).join("");

    card.innerHTML = `
      <div style="display:flex;gap:12px;align-items:flex-start;width:100%">
        <div style="flex:1">
          <div style="display:flex;justify-content:space-between;align-items:flex-start">
            <div>
              <div style="font-weight:800;color:#007bff">Order ID: ${escapeHtml(order.orderId || "")}</div>
              <div style="margin-top:6px"><b>Date:</b> ${new Date(order.paymentDate).toLocaleString()}</div>
              <div style="margin-top:6px"><b>Payment method:</b> ${escapeHtml(order.paymentMethod || "")}</div>
              <div style="margin-top:6px"><b>Total:</b> ₹${escapeHtml(order.totalAmount || 0)}</div>
            </div>
            <div style="text-align:right">
              <div style="font-weight:700">${escapeHtml(order.status || "Processing")}</div>
            </div>
          </div>

          <div style="margin-top:12px">${itemsHtml}</div>
        </div>

        <div style="display:flex;flex-direction:column;gap:8px;align-items:flex-end">
          
          <button class="btn cancel-order" data-orderid="${escapeHtml(order.orderId)}" ${order.status === "Cancelled" ? "disabled" : ""}>Cancel</button>
        </div>
      </div>
    `;

    container.appendChild(card);
  });

  // 🔥 FIXED: Attach listeners AFTER DOM finishes drawing
  setTimeout(() => {
    document.querySelectorAll(".view-invoice")
        .forEach(btn => btn.addEventListener("click", viewInvoiceHandler));

    document.querySelectorAll(".cancel-order")
        .forEach(btn => btn.addEventListener("click", cancelOrderHandler));
  }, 50);
}

// Cancel handler
async function cancelOrderHandler(e) {
  const orderId = e.currentTarget.dataset.orderid;
  if (!confirm("Are you sure you want to cancel this order? A convenience charge will be deducted.")) return;

  try {
    const res = await fetch(`/api/orders/cancel/${encodeURIComponent(orderId)}`, { method: "PUT" });
    const data = await res.json();
    if (!res.ok) {
      alert("Cancel failed: " + (data.message || JSON.stringify(data)));
      return;
    }

    alert(`Order cancelled. Refund amount ₹${data.refundAmount} (Convenience charge ₹${data.convenienceCharge}).`);
    const userEmail = localStorage.getItem("userEmail");
    await loadOrders(userEmail);
  } catch (err) {
    console.error(err);
    alert("Cancel failed, try again");
  }
}

// View invoice
async function viewInvoiceHandler(e) {
  const orderId = e.currentTarget.dataset.orderid;

  try {
    const res = await fetch(`/api/orders/id/${encodeURIComponent(orderId)}`);
    const order = await res.json();

    if (!order) return alert("Order not found");

    // FIX 1 — Safe payment date
    const dateFormatted = order.paymentDate
      ? new Date(order.paymentDate).toLocaleString()
      : "N/A";

    // FIX 2 — Always use totalAmount
    const totalFormatted = order.totalAmount || 0;

    // FIX 3 — Check cancelled order properly
    const isCancelled = order.status === "Cancelled";

    // FIX 4 — Items only shown if not cancelled
    let itemsRows = "";

    const items = order.items || order.orderedItems || [];

    if (!isCancelled && order.items && order.items.length > 0) {
      itemsRows = order.items.map(it => `
        <tr>
          <td style="padding:8px;border:1px solid #ddd">
            <img src="${escapeHtml(it.image || "")}" width="60">
          </td>
          <td style="padding:8px;border:1px solid #ddd">
            ${escapeHtml(it.productName)}
          </td>
          <td style="padding:8px;border:1px solid #ddd;text-align:center">
            ${escapeHtml(it.quantity)}
          </td>
          <td style="padding:8px;border:1px solid #ddd;text-align:right">
            ₹${escapeHtml(it.price)}
          </td>
          <td style="padding:8px;border:1px solid #ddd;text-align:right">
            ₹${(it.price * it.quantity).toFixed(2)}
          </td>
        </tr>
      `).join("");
    } else {
      itemsRows = `
        <tr>
          <td colspan="5" style="padding:10px;text-align:center;color:red;font-weight:600">
            This order was cancelled. No items to display.
          </td>
        </tr>
      `;
    }

    const win = window.open("", "_blank", "width=800,height=900");

    const html = `
      <html><head><title>Invoice ${escapeHtml(order.orderId)}</title>
      <style>
        body{font-family:Arial;padding:20px}
        table{width:100%;border-collapse:collapse;margin-top:12px}
        th,td{border:1px solid #ccc;padding:8px}
      </style>
      </head><body>

      <h2>Our Store – Invoice</h2>
      <p>
        <b>Order ID:</b> ${escapeHtml(order.orderId)}<br>
        <b>Date:</b> ${dateFormatted}<br>
        <b>Email:</b> ${escapeHtml(order.userEmail)}
      </p>

      <table>
        <thead><tr>
          <th>Image</th><th>Product</th><th>Qty</th><th>Price</th><th>Subtotal</th>
        </tr></thead>
        <tbody>${itemsRows}</tbody>
      </table>

      <h3>Total: ₹${totalFormatted}</h3>

      <button onclick="window.print()">Print / Save as PDF</button>
      </body></html>
    `;

    win.document.open();
    win.document.write(html);
    win.document.close();

  } catch (err) {
    console.error(err);
    alert("Failed to load invoice");
  }
}




// Escape helper
function escapeHtml(s) {
  if (!s && s !== 0) return "";
  return String(s).replace(/[&<>"']/g, m =>
    ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m])
  );
}
