// FIXED admin_products.js
// Uses ONLY the real working filter inputs in your admin page

document.addEventListener("DOMContentLoaded", () => {
    const nameInput = document.getElementById("filterName");
    const categoryInput = document.getElementById("filterCategory");
    const minPriceInput = document.getElementById("filterMin");
    const maxPriceInput = document.getElementById("filterMax");
    const goBtn = document.getElementById("filterGo");
    const productList = document.getElementById("productList");

    async function loadProducts() {
        let url = "/api/products?";
        
        if (nameInput.value.trim())
            url += `name=${encodeURIComponent(nameInput.value.trim())}&`;

        if (categoryInput.value.trim())
            url += `category=${encodeURIComponent(categoryInput.value.trim())}&`;

        if (minPriceInput.value)
            url += `minPrice=${minPriceInput.value}&`;

        if (maxPriceInput.value)
            url += `maxPrice=${maxPriceInput.value}&`;

        const res = await fetch(url);
        const products = await res.json();

        productList.innerHTML = "";

        if (!products.length) {
            productList.innerHTML = `<p>No products found</p>`;
            return;
        }

        products.forEach(p => {
            productList.innerHTML += `
                <div class="product-item">
                    <strong>${p.name}</strong> — ₹${p.price}<br>
                    <small>Category: ${p.category}</small>
                </div>
            `;
        });
    }
    async function fetchProductsFromServer(filters = {}) {
  const params = new URLSearchParams();
  for (const k in filters) {
    if (filters[k] !== undefined && filters[k] !== '') params.append(k, filters[k]);
  }
  const url = '/api/products' + (params.toString() ? ('?' + params.toString()) : '');
  const res = await fetch(url);
  const data = await res.json();
  return data;
}

async function loadProducts() {
  const tbl = document.getElementById('productsTable');
  if (!tbl) return;
  tbl.innerHTML = '<div class="muted p-3">Loading...</div>';

  try {
    // Collect filter values
    const name = document.getElementById('pSearchName')?.value.trim() || '';
    const category = document.getElementById('pSearchCategory')?.value || '';
    const minPrice = document.getElementById('pMinPrice')?.value || '';
    const maxPrice = document.getElementById('pMaxPrice')?.value || '';

    const filters = {};
    if (name) filters.name = name;
    if (category) filters.category = category;
    if (minPrice) filters.minPrice = minPrice;
    if (maxPrice) filters.maxPrice = maxPrice;

    // Fetch filtered products
    productsCache = await fetchProductsFromServer(filters);

    if (!productsCache.length) {
      tbl.innerHTML = '<div class="muted p-3">No products found</div>';
      return;
    }

    // Render products
    tbl.innerHTML = productsCache.map(p => {
      const id = p._id && (p._id.$oid || p._id);
      return `
        <div style="display:flex;gap:10px;padding:10px;border-bottom:1px solid #f0f0f0;align-items:center">
          <img src="${escapeHtml(p.image||'')}" style="width:70px;height:70px;object-fit:cover;border-radius:8px">
          <div style="flex:1">
            <div style="font-weight:700">${escapeHtml(p.name)}</div>
            <div class="muted">${escapeHtml(p.category || '')}</div>
            <div style="margin-top:6px">₹${escapeHtml(p.price)} • Stock: ${escapeHtml(p.stock || 0)}</div>
          </div>
          <div style="display:flex;flex-direction:column;gap:6px">
            <button class="btn btn-sm btn-warning" onclick="editProductPrompt('${escapeHtml(id)}')">Edit</button>
            <button class="btn btn-sm btn-danger" onclick="deleteProduct('${escapeHtml(id)}')">Delete</button>
          </div>
        </div>
      `;
    }).join('');

  } catch (err) {
    console.error('loadProducts err', err);
    tbl.innerHTML = '<div class="muted p-3">Error loading products</div>';
  }
}

// Attach filter button
document.getElementById('pApply')?.addEventListener('click', loadProducts);


    // Load on button click
    goBtn.addEventListener("click", loadProducts);

    // Optional: auto-load initial products
    loadProducts();
});
