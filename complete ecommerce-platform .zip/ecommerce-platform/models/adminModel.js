// adminModel.js
const bcrypt = require("bcrypt");

async function createAdmin(db, email, password) {
  try {
    const admins = db.collection("admins");

    const existingAdmin = await admins.findOne({ email: email });
    if (existingAdmin) {
      console.log("ℹ️ Admin already exists:", email);
      return;
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    await admins.insertOne({
      email: email,
      password: hashedPassword
    });

    console.log("✅ Admin created:", email);
  } catch (error) {
    console.error("❌ Error creating admin:", error);
  }
}

async function findAdmin(db, email) {
  const admins = db.collection("admins");
  const admin = await admins.findOne({ email: email });
  return admin;
}

async function addProduct(db, name, price, stock) {
  const products = db.collection("products");
  await products.insertOne({ name, price, stock });
  console.log("✅ Product added:", name);
}

async function getAllProducts(db) {
  const products = db.collection("products");
  return await products.find().toArray();
}

module.exports = { createAdmin, findAdmin, addProduct, getAllProducts };
